namespace VibeCodeBank.Data.Configuration;

public static class DatabaseConfiguration
{
    public static string GetConnectionString()
    {
        return "Host=172.26.170.182;Database=mybank;Username=postgres;Password=Abcd1234";
    }

    public static string GetConnectionString(string host, string database, string username, string password, int port = 5432)
    {
        return $"Host={host};Port={port};Database={database};Username={username};Password={password}";
    }
}
