using VibeCodeBank.Data.Models;

namespace VibeCodeBank.Data.Repositories;

public interface IAccountRepository : IRepository<Account>
{
    Task<Account?> GetByAccountNumberAsync(string accountNumber);
    Task<IEnumerable<Account>> GetByCustomerIdAsync(int customerId);
    Task<IEnumerable<Account>> GetActiveAccountsAsync();
}
