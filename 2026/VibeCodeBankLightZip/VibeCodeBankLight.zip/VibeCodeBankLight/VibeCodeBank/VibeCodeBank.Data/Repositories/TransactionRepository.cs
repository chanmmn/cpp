using Microsoft.EntityFrameworkCore;
using VibeCodeBank.Data.Context;
using VibeCodeBank.Data.Models;

namespace VibeCodeBank.Data.Repositories;

public class TransactionRepository : Repository<Transaction>, ITransactionRepository
{
    public TransactionRepository(MyBankDbContext context) : base(context)
    {
    }

    public override async Task<Transaction?> GetByIdAsync(int id)
    {
        return await _dbSet
            .Include(t => t.Account)
                .ThenInclude(a => a.Customer)
            .FirstOrDefaultAsync(t => t.TransactionId == id);
    }

    public override async Task<IEnumerable<Transaction>> GetAllAsync()
    {
        return await _dbSet
            .Include(t => t.Account)
            .ToListAsync();
    }

    public async Task<IEnumerable<Transaction>> GetByAccountIdAsync(int accountId)
    {
        return await _dbSet
            .Include(t => t.Account)
            .Where(t => t.AccountId == accountId)
            .OrderByDescending(t => t.TransactionDate)
            .ToListAsync();
    }

    public async Task<IEnumerable<Transaction>> GetByDateRangeAsync(DateTime startDate, DateTime endDate)
    {
        return await _dbSet
            .Include(t => t.Account)
            .Where(t => t.TransactionDate >= startDate && t.TransactionDate <= endDate)
            .OrderByDescending(t => t.TransactionDate)
            .ToListAsync();
    }

    public async Task<IEnumerable<Transaction>> GetByTypeAsync(string transactionType)
    {
        return await _dbSet
            .Include(t => t.Account)
            .Where(t => t.TransactionType == transactionType)
            .OrderByDescending(t => t.TransactionDate)
            .ToListAsync();
    }
}
