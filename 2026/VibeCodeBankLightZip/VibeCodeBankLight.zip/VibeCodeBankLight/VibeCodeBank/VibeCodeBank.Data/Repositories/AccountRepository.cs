using Microsoft.EntityFrameworkCore;
using VibeCodeBank.Data.Context;
using VibeCodeBank.Data.Models;

namespace VibeCodeBank.Data.Repositories;

public class AccountRepository : Repository<Account>, IAccountRepository
{
    public AccountRepository(MyBankDbContext context) : base(context)
    {
    }

    public override async Task<Account?> GetByIdAsync(int id)
    {
        return await _dbSet
            .Include(a => a.Customer)
            .Include(a => a.Transactions)
            .FirstOrDefaultAsync(a => a.AccountId == id);
    }

    public override async Task<IEnumerable<Account>> GetAllAsync()
    {
        return await _dbSet
            .Include(a => a.Customer)
            .ToListAsync();
    }

    public async Task<Account?> GetByAccountNumberAsync(string accountNumber)
    {
        return await _dbSet
            .Include(a => a.Customer)
            .Include(a => a.Transactions)
            .FirstOrDefaultAsync(a => a.AccountNumber == accountNumber);
    }

    public async Task<IEnumerable<Account>> GetByCustomerIdAsync(int customerId)
    {
        return await _dbSet
            .Include(a => a.Transactions)
            .Where(a => a.CustomerId == customerId)
            .ToListAsync();
    }

    public async Task<IEnumerable<Account>> GetActiveAccountsAsync()
    {
        return await _dbSet
            .Include(a => a.Customer)
            .Where(a => a.Status == "ACTIVE")
            .ToListAsync();
    }
}
