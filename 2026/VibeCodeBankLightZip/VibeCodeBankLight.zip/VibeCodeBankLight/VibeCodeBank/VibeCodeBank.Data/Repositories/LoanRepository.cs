using Microsoft.EntityFrameworkCore;
using VibeCodeBank.Data.Context;
using VibeCodeBank.Data.Models;

namespace VibeCodeBank.Data.Repositories;

public class LoanRepository : Repository<Loan>, ILoanRepository
{
    public LoanRepository(MyBankDbContext context) : base(context)
    {
    }

    public override async Task<Loan?> GetByIdAsync(int id)
    {
        return await _dbSet
            .Include(l => l.Customer)
            .FirstOrDefaultAsync(l => l.LoanId == id);
    }

    public override async Task<IEnumerable<Loan>> GetAllAsync()
    {
        return await _dbSet
            .Include(l => l.Customer)
            .ToListAsync();
    }

    public async Task<IEnumerable<Loan>> GetByCustomerIdAsync(int customerId)
    {
        return await _dbSet
            .Where(l => l.CustomerId == customerId)
            .ToListAsync();
    }

    public async Task<IEnumerable<Loan>> GetActiveLoansByCustomerIdAsync(int customerId)
    {
        return await _dbSet
            .Where(l => l.CustomerId == customerId && l.Status == "ACTIVE")
            .ToListAsync();
    }

    public async Task<IEnumerable<Loan>> GetActiveLoansAsync()
    {
        return await _dbSet
            .Include(l => l.Customer)
            .Where(l => l.Status == "ACTIVE")
            .ToListAsync();
    }
}
