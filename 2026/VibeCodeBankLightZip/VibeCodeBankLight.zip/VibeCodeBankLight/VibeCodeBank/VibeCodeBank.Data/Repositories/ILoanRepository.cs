using VibeCodeBank.Data.Models;

namespace VibeCodeBank.Data.Repositories;

public interface ILoanRepository : IRepository<Loan>
{
    Task<IEnumerable<Loan>> GetByCustomerIdAsync(int customerId);
    Task<IEnumerable<Loan>> GetActiveLoansByCustomerIdAsync(int customerId);
    Task<IEnumerable<Loan>> GetActiveLoansAsync();
}
