using Microsoft.EntityFrameworkCore;
using VibeCodeBank.Data.Context;
using VibeCodeBank.Data.Models;

namespace VibeCodeBank.Data.Repositories;

public class CustomerRepository : Repository<Customer>, ICustomerRepository
{
    public CustomerRepository(MyBankDbContext context) : base(context)
    {
    }

    public override async Task<Customer?> GetByIdAsync(int id)
    {
        return await _dbSet
            .Include(c => c.Accounts)
            .Include(c => c.Loans)
            .FirstOrDefaultAsync(c => c.CustomerId == id);
    }

    public override async Task<IEnumerable<Customer>> GetAllAsync()
    {
        return await _dbSet
            .Include(c => c.Accounts)
            .Include(c => c.Loans)
            .ToListAsync();
    }

    public async Task<Customer?> GetByEmailAsync(string email)
    {
        return await _dbSet
            .Include(c => c.Accounts)
            .Include(c => c.Loans)
            .FirstOrDefaultAsync(c => c.Email == email);
    }

    public async Task<IEnumerable<Customer>> GetActiveCustomersAsync()
    {
        return await _dbSet
            .Include(c => c.Accounts)
            .Include(c => c.Loans)
            .Where(c => c.IsActive)
            .ToListAsync();
    }
}
