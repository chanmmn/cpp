using VibeCodeBank.Data.Models;

namespace VibeCodeBank.Data.Repositories;

public interface IFundTransferRepository : IRepository<FundTransfer>
{
    Task<IEnumerable<FundTransfer>> GetByAccountIdAsync(int accountId);
    Task<IEnumerable<FundTransfer>> GetByDateRangeAsync(DateTime startDate, DateTime endDate);
}
