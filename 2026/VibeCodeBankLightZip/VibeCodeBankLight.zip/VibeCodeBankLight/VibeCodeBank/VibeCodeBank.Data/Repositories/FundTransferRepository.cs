using Microsoft.EntityFrameworkCore;
using VibeCodeBank.Data.Context;
using VibeCodeBank.Data.Models;

namespace VibeCodeBank.Data.Repositories;

public class FundTransferRepository : Repository<FundTransfer>, IFundTransferRepository
{
    public FundTransferRepository(MyBankDbContext context) : base(context)
    {
    }

    public override async Task<FundTransfer?> GetByIdAsync(int id)
    {
        return await _dbSet
            .Include(ft => ft.FromAccount)
                .ThenInclude(a => a.Customer)
            .Include(ft => ft.ToAccount)
                .ThenInclude(a => a.Customer)
            .FirstOrDefaultAsync(ft => ft.TransferId == id);
    }

    public override async Task<IEnumerable<FundTransfer>> GetAllAsync()
    {
        return await _dbSet
            .Include(ft => ft.FromAccount)
            .Include(ft => ft.ToAccount)
            .ToListAsync();
    }

    public async Task<IEnumerable<FundTransfer>> GetByAccountIdAsync(int accountId)
    {
        return await _dbSet
            .Include(ft => ft.FromAccount)
            .Include(ft => ft.ToAccount)
            .Where(ft => ft.FromAccountId == accountId || ft.ToAccountId == accountId)
            .OrderByDescending(ft => ft.TransferDate)
            .ToListAsync();
    }

    public async Task<IEnumerable<FundTransfer>> GetByDateRangeAsync(DateTime startDate, DateTime endDate)
    {
        return await _dbSet
            .Include(ft => ft.FromAccount)
            .Include(ft => ft.ToAccount)
            .Where(ft => ft.TransferDate >= startDate && ft.TransferDate <= endDate)
            .OrderByDescending(ft => ft.TransferDate)
            .ToListAsync();
    }
}
