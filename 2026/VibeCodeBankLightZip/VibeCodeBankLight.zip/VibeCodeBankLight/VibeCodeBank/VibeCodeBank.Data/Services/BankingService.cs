using VibeCodeBank.Data.Models;
using VibeCodeBank.Data.Repositories;

namespace VibeCodeBank.Data.Services;

public class BankingService : IBankingService
{
    private readonly IAccountRepository _accountRepo;
    private readonly ITransactionRepository _transactionRepo;
    private readonly IFundTransferRepository _fundTransferRepo;
    private readonly ICustomerRepository _customerRepo;

    public BankingService(
        IAccountRepository accountRepo,
        ITransactionRepository transactionRepo,
        IFundTransferRepository fundTransferRepo,
        ICustomerRepository customerRepo)
    {
        _accountRepo = accountRepo;
        _transactionRepo = transactionRepo;
        _fundTransferRepo = fundTransferRepo;
        _customerRepo = customerRepo;
    }

    public async Task<Account> CreateAccountForCustomerAsync(int customerId, string accountType, decimal initialDeposit)
    {
        var customer = await _customerRepo.GetByIdAsync(customerId);
        if (customer == null)
            throw new InvalidOperationException($"Customer with ID {customerId} not found.");

        if (!customer.IsActive)
            throw new InvalidOperationException("Cannot create account for inactive customer.");

        var accountNumber = GenerateAccountNumber();

        var account = new Account
        {
            CustomerId = customerId,
            AccountNumber = accountNumber,
            AccountType = accountType.ToUpper(),
            Balance = initialDeposit,
            Currency = "USD",
            Status = "ACTIVE"
        };

        var createdAccount = await _accountRepo.AddAsync(account);

        if (initialDeposit > 0)
        {
            var transaction = new Transaction
            {
                AccountId = createdAccount.AccountId,
                TransactionType = "DEPOSIT",
                Amount = initialDeposit,
                Description = "Initial deposit",
                ReferenceNumber = GenerateReferenceNumber("TXN"),
                BalanceAfter = initialDeposit,
                Status = "COMPLETED"
            };

            await _transactionRepo.AddAsync(transaction);
        }

        return createdAccount;
    }

    public async Task<Transaction> DepositAsync(string accountNumber, decimal amount, string description)
    {
        if (amount <= 0)
            throw new ArgumentException("Deposit amount must be greater than zero.");

        var account = await _accountRepo.GetByAccountNumberAsync(accountNumber);
        if (account == null)
            throw new InvalidOperationException($"Account {accountNumber} not found.");

        if (account.Status != "ACTIVE")
            throw new InvalidOperationException($"Account {accountNumber} is not active.");

        account.Balance += amount;
        await _accountRepo.UpdateAsync(account);

        var transaction = new Transaction
        {
            AccountId = account.AccountId,
            TransactionType = "DEPOSIT",
            Amount = amount,
            Description = description,
            ReferenceNumber = GenerateReferenceNumber("TXN"),
            BalanceAfter = account.Balance,
            Status = "COMPLETED"
        };

        return await _transactionRepo.AddAsync(transaction);
    }

    public async Task<Transaction> WithdrawAsync(string accountNumber, decimal amount, string description)
    {
        if (amount <= 0)
            throw new ArgumentException("Withdrawal amount must be greater than zero.");

        var account = await _accountRepo.GetByAccountNumberAsync(accountNumber);
        if (account == null)
            throw new InvalidOperationException($"Account {accountNumber} not found.");

        if (account.Status != "ACTIVE")
            throw new InvalidOperationException($"Account {accountNumber} is not active.");

        if (account.Balance < amount)
            throw new InvalidOperationException($"Insufficient funds. Current balance: {account.Balance:C}");

        account.Balance -= amount;
        await _accountRepo.UpdateAsync(account);

        var transaction = new Transaction
        {
            AccountId = account.AccountId,
            TransactionType = "WITHDRAWAL",
            Amount = amount,
            Description = description,
            ReferenceNumber = GenerateReferenceNumber("TXN"),
            BalanceAfter = account.Balance,
            Status = "COMPLETED"
        };

        return await _transactionRepo.AddAsync(transaction);
    }

    public async Task<(Transaction fromTransaction, Transaction toTransaction)> TransferAsync(
        string fromAccountNumber, string toAccountNumber, decimal amount, string description)
    {
        if (amount <= 0)
            throw new ArgumentException("Transfer amount must be greater than zero.");

        if (fromAccountNumber == toAccountNumber)
            throw new ArgumentException("Cannot transfer to the same account.");

        var fromAccount = await _accountRepo.GetByAccountNumberAsync(fromAccountNumber);
        if (fromAccount == null)
            throw new InvalidOperationException($"Source account {fromAccountNumber} not found.");

        var toAccount = await _accountRepo.GetByAccountNumberAsync(toAccountNumber);
        if (toAccount == null)
            throw new InvalidOperationException($"Destination account {toAccountNumber} not found.");

        if (fromAccount.Status != "ACTIVE")
            throw new InvalidOperationException($"Source account {fromAccountNumber} is not active.");

        if (toAccount.Status != "ACTIVE")
            throw new InvalidOperationException($"Destination account {toAccountNumber} is not active.");

        if (fromAccount.Balance < amount)
            throw new InvalidOperationException($"Insufficient funds in source account. Current balance: {fromAccount.Balance:C}");

        fromAccount.Balance -= amount;
        toAccount.Balance += amount;

        await _accountRepo.UpdateAsync(fromAccount);
        await _accountRepo.UpdateAsync(toAccount);

        var referenceNumber = GenerateReferenceNumber("TRF");

        var fromTransaction = new Transaction
        {
            AccountId = fromAccount.AccountId,
            TransactionType = "TRANSFER_OUT",
            Amount = amount,
            Description = $"{description} - To: {toAccountNumber}",
            ReferenceNumber = $"{referenceNumber}-OUT",
            BalanceAfter = fromAccount.Balance,
            Status = "COMPLETED"
        };

        var toTransaction = new Transaction
        {
            AccountId = toAccount.AccountId,
            TransactionType = "TRANSFER_IN",
            Amount = amount,
            Description = $"{description} - From: {fromAccountNumber}",
            ReferenceNumber = $"{referenceNumber}-IN",
            BalanceAfter = toAccount.Balance,
            Status = "COMPLETED"
        };

        var fromTxn = await _transactionRepo.AddAsync(fromTransaction);
        var toTxn = await _transactionRepo.AddAsync(toTransaction);

        var fundTransfer = new FundTransfer
        {
            FromAccountId = fromAccount.AccountId,
            ToAccountId = toAccount.AccountId,
            Amount = amount,
            Description = description,
            ReferenceNumber = referenceNumber,
            Status = "COMPLETED"
        };

        await _fundTransferRepo.AddAsync(fundTransfer);

        return (fromTxn, toTxn);
    }

    public async Task<decimal> GetAccountBalanceAsync(string accountNumber)
    {
        var account = await _accountRepo.GetByAccountNumberAsync(accountNumber);
        if (account == null)
            throw new InvalidOperationException($"Account {accountNumber} not found.");

        return account.Balance;
    }

    private string GenerateAccountNumber()
    {
        return $"ACC{DateTime.Now:yyyyMMddHHmmss}{new Random().Next(1000, 9999)}";
    }

    private string GenerateReferenceNumber(string prefix)
    {
        return $"{prefix}{DateTime.Now:yyyyMMddHHmmss}{new Random().Next(1000, 9999)}";
    }
}
