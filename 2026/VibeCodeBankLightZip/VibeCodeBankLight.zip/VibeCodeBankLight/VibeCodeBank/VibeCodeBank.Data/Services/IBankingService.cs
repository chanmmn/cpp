using VibeCodeBank.Data.Models;
using VibeCodeBank.Data.Repositories;

namespace VibeCodeBank.Data.Services;

public interface IBankingService
{
    Task<Account> CreateAccountForCustomerAsync(int customerId, string accountType, decimal initialDeposit);
    Task<Transaction> DepositAsync(string accountNumber, decimal amount, string description);
    Task<Transaction> WithdrawAsync(string accountNumber, decimal amount, string description);
    Task<(Transaction fromTransaction, Transaction toTransaction)> TransferAsync(string fromAccountNumber, string toAccountNumber, decimal amount, string description);
    Task<decimal> GetAccountBalanceAsync(string accountNumber);
}
