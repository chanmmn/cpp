using Microsoft.EntityFrameworkCore;
using VibeCodeBank.Data.Models;

namespace VibeCodeBank.Data.Context;

public class MyBankDbContext : DbContext
{
    public MyBankDbContext(DbContextOptions<MyBankDbContext> options) : base(options)
    {
    }

    public DbSet<Customer> Customers { get; set; }
    public DbSet<Account> Accounts { get; set; }
    public DbSet<Transaction> Transactions { get; set; }
    public DbSet<FundTransfer> FundTransfers { get; set; }
    public DbSet<Loan> Loans { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Customer>(entity =>
        {
            entity.HasIndex(e => e.Email).HasDatabaseName("idx_customers_email");
            entity.HasIndex(e => e.Phone).HasDatabaseName("idx_customers_phone");

            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("CURRENT_TIMESTAMP")
                .ValueGeneratedOnAdd();

            entity.Property(e => e.UpdatedAt)
                .HasDefaultValueSql("CURRENT_TIMESTAMP")
                .ValueGeneratedOnAddOrUpdate();
        });

        modelBuilder.Entity<Account>(entity =>
        {
            entity.HasIndex(e => e.AccountNumber).HasDatabaseName("idx_accounts_account_number");
            entity.HasIndex(e => e.CustomerId).HasDatabaseName("idx_accounts_customer_id");
            entity.HasIndex(e => e.Status).HasDatabaseName("idx_accounts_status");

            entity.Property(e => e.OpenedDate)
                .HasDefaultValueSql("CURRENT_DATE")
                .ValueGeneratedOnAdd();

            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("CURRENT_TIMESTAMP")
                .ValueGeneratedOnAdd();

            entity.Property(e => e.UpdatedAt)
                .HasDefaultValueSql("CURRENT_TIMESTAMP")
                .ValueGeneratedOnAddOrUpdate();

            entity.HasOne(e => e.Customer)
                .WithMany(c => c.Accounts)
                .HasForeignKey(e => e.CustomerId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Transaction>(entity =>
        {
            entity.HasIndex(e => e.AccountId).HasDatabaseName("idx_transactions_account_id");
            entity.HasIndex(e => e.TransactionDate).HasDatabaseName("idx_transactions_date");
            entity.HasIndex(e => e.TransactionType).HasDatabaseName("idx_transactions_type");

            entity.Property(e => e.TransactionDate)
                .HasDefaultValueSql("CURRENT_TIMESTAMP")
                .ValueGeneratedOnAdd();

            entity.HasOne(e => e.Account)
                .WithMany(a => a.Transactions)
                .HasForeignKey(e => e.AccountId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<FundTransfer>(entity =>
        {
            entity.HasIndex(e => e.FromAccountId).HasDatabaseName("idx_fund_transfers_from_account");
            entity.HasIndex(e => e.ToAccountId).HasDatabaseName("idx_fund_transfers_to_account");
            entity.HasIndex(e => e.TransferDate).HasDatabaseName("idx_fund_transfers_date");

            entity.Property(e => e.TransferDate)
                .HasDefaultValueSql("CURRENT_TIMESTAMP")
                .ValueGeneratedOnAdd();

            entity.HasOne(e => e.FromAccount)
                .WithMany(a => a.FundTransfersFrom)
                .HasForeignKey(e => e.FromAccountId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(e => e.ToAccount)
                .WithMany(a => a.FundTransfersTo)
                .HasForeignKey(e => e.ToAccountId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Loan>(entity =>
        {
            entity.HasOne(e => e.Customer)
                .WithMany(c => c.Loans)
                .HasForeignKey(e => e.CustomerId)
                .OnDelete(DeleteBehavior.Restrict);
        });
    }
}
