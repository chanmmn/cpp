using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using VibeCodeBank.Data.Context;
using VibeCodeBank.Data.Repositories;
using VibeCodeBank.Data.Services;

namespace VibeCodeBank.Data.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddVibeBankDataServices(
        this IServiceCollection services, 
        string connectionString)
    {
        services.AddDbContext<MyBankDbContext>(options =>
            options.UseNpgsql(connectionString));

        services.AddScoped<ICustomerRepository, CustomerRepository>();
        services.AddScoped<IAccountRepository, AccountRepository>();
        services.AddScoped<ITransactionRepository, TransactionRepository>();
        services.AddScoped<IFundTransferRepository, FundTransferRepository>();
        services.AddScoped<ILoanRepository, LoanRepository>();
        services.AddScoped<IBankingService, BankingService>();

        return services;
    }
}
