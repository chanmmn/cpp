using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VibeCodeBank.Data.Models;

[Table("accounts")]
public class Account
{
    [Key]
    [Column("account_id")]
    public int AccountId { get; set; }

    [Column("customer_id")]
    public int CustomerId { get; set; }

    [Required]
    [MaxLength(20)]
    [Column("account_number")]
    public string AccountNumber { get; set; } = string.Empty;

    [Required]
    [MaxLength(20)]
    [Column("account_type")]
    public string AccountType { get; set; } = string.Empty;

    [Column("balance", TypeName = "decimal(15,2)")]
    public decimal Balance { get; set; } = 0.00m;

    [MaxLength(3)]
    [Column("currency")]
    public string Currency { get; set; } = "USD";

    [Column("opened_date")]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public DateTime? OpenedDate { get; set; }

    [MaxLength(20)]
    [Column("status")]
    public string Status { get; set; } = "ACTIVE";

    [Column("created_at")]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public DateTime? CreatedAt { get; set; }

    [Column("updated_at")]
    [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
    public DateTime? UpdatedAt { get; set; }

    [ForeignKey("CustomerId")]
    public Customer Customer { get; set; } = null!;

    public ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();
    public ICollection<FundTransfer> FundTransfersFrom { get; set; } = new List<FundTransfer>();
    public ICollection<FundTransfer> FundTransfersTo { get; set; } = new List<FundTransfer>();
}
