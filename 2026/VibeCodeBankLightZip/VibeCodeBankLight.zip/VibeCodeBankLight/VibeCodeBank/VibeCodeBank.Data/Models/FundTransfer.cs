using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VibeCodeBank.Data.Models;

[Table("fund_transfers")]
public class FundTransfer
{
    [Key]
    [Column("transfer_id")]
    public int TransferId { get; set; }

    [Column("from_account_id")]
    public int FromAccountId { get; set; }

    [Column("to_account_id")]
    public int ToAccountId { get; set; }

    [Column("amount", TypeName = "decimal(15,2)")]
    public decimal Amount { get; set; }

    [Column("description")]
    public string? Description { get; set; }

    [Column("transfer_date")]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public DateTime? TransferDate { get; set; }

    [MaxLength(50)]
    [Column("reference_number")]
    public string? ReferenceNumber { get; set; }

    [MaxLength(20)]
    [Column("status")]
    public string Status { get; set; } = "COMPLETED";

    [ForeignKey("FromAccountId")]
    public Account FromAccount { get; set; } = null!;

    [ForeignKey("ToAccountId")]
    public Account ToAccount { get; set; } = null!;
}
