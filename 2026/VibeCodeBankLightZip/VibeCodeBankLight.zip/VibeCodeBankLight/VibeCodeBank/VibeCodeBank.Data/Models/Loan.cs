using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VibeCodeBank.Data.Models;

[Table("loans")]
public class Loan
{
    [Key]
    [Column("loan_id")]
    public int LoanId { get; set; }

    [Column("customer_id")]
    public int CustomerId { get; set; }

    [Required]
    [MaxLength(50)]
    [Column("loan_type")]
    public string LoanType { get; set; } = string.Empty;

    [Column("loan_amount", TypeName = "decimal(15,2)")]
    public decimal LoanAmount { get; set; }

    [Column("interest_rate", TypeName = "decimal(5,2)")]
    public decimal InterestRate { get; set; }

    [Column("term_months")]
    public int TermMonths { get; set; }

    [Column("start_date")]
    public DateTime StartDate { get; set; }

    [Column("end_date")]
    public DateTime EndDate { get; set; }

    [Column("monthly_payment", TypeName = "decimal(15,2)")]
    public decimal MonthlyPayment { get; set; }

    [Column("remaining_balance", TypeName = "decimal(15,2)")]
    public decimal RemainingBalance { get; set; }

    [MaxLength(20)]
    [Column("status")]
    public string Status { get; set; } = "ACTIVE";

    [ForeignKey("CustomerId")]
    public Customer Customer { get; set; } = null!;
}
