using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VibeCodeBank.Data.Models;

[Table("transactions")]
public class Transaction
{
    [Key]
    [Column("transaction_id")]
    public int TransactionId { get; set; }

    [Column("account_id")]
    public int AccountId { get; set; }

    [Required]
    [MaxLength(20)]
    [Column("transaction_type")]
    public string TransactionType { get; set; } = string.Empty;

    [Column("amount", TypeName = "decimal(15,2)")]
    public decimal Amount { get; set; }

    [Column("description")]
    public string? Description { get; set; }

    [Column("transaction_date")]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public DateTime? TransactionDate { get; set; }

    [MaxLength(50)]
    [Column("reference_number")]
    public string? ReferenceNumber { get; set; }

    [Column("balance_after", TypeName = "decimal(15,2)")]
    public decimal BalanceAfter { get; set; }

    [MaxLength(20)]
    [Column("status")]
    public string Status { get; set; } = "COMPLETED";

    [ForeignKey("AccountId")]
    public Account Account { get; set; } = null!;
}
