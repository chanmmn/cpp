﻿using Microsoft.Extensions.DependencyInjection;
using VibeCodeBank.Data.Configuration;
using VibeCodeBank.Data.Context;
using VibeCodeBank.Data.Extensions;
using VibeCodeBank.Data.Models;
using VibeCodeBank.Data.Repositories;

internal class Program
{
    private static async Task Main(string[] args)
    {
        AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);

        var services = new ServiceCollection();

        string connectionString = DatabaseConfiguration.GetConnectionString();

        services.AddVibeBankDataServices(connectionString);

        var serviceProvider = services.BuildServiceProvider();

        Console.WriteLine("=== VibeCodeBank - Entity Framework Core with PostgreSQL ===\n");

        try
        {
            using (var scope = serviceProvider.CreateScope())
            {
                var context = scope.ServiceProvider.GetRequiredService<MyBankDbContext>();

                Console.WriteLine("Testing database connection...");
                if (await context.Database.CanConnectAsync())
                {
                    Console.WriteLine("✓ Successfully connected to PostgreSQL database!\n");
                }
                else
                {
                    Console.WriteLine("✗ Failed to connect to database.\n");
                    return;
                }

                var customerRepo = scope.ServiceProvider.GetRequiredService<ICustomerRepository>();
                var accountRepo = scope.ServiceProvider.GetRequiredService<IAccountRepository>();
                var transactionRepo = scope.ServiceProvider.GetRequiredService<ITransactionRepository>();

                Console.WriteLine("=== CRUD Operations Demo ===\n");

                Console.WriteLine("--- Fetching all customers ---");
                var customers = await customerRepo.GetAllAsync();
                Console.WriteLine($"Total customers: {customers.Count()}");
                foreach (var customer in customers.Take(5))
                {
                    Console.WriteLine($"  • {customer.FirstName} {customer.LastName} ({customer.Email}) - Accounts: {customer.Accounts.Count}");
                }
                Console.WriteLine();

                if (customers.Any())
                {
                    var firstCustomer = customers.First();
                    Console.WriteLine($"--- Customer Details: {firstCustomer.FirstName} {firstCustomer.LastName} ---");
                    Console.WriteLine($"  Email: {firstCustomer.Email}");
                    Console.WriteLine($"  Phone: {firstCustomer.Phone}");
                    Console.WriteLine($"  Active: {firstCustomer.IsActive}");
                    Console.WriteLine($"  Number of Accounts: {firstCustomer.Accounts.Count}");
                    Console.WriteLine();

                    var customerAccounts = await accountRepo.GetByCustomerIdAsync(firstCustomer.CustomerId);
                    Console.WriteLine($"--- Accounts for {firstCustomer.FirstName} {firstCustomer.LastName} ---");
                    foreach (var account in customerAccounts)
                    {
                        Console.WriteLine($"  • Account: {account.AccountNumber}");
                        Console.WriteLine($"    Type: {account.AccountType}");
                        Console.WriteLine($"    Balance: {account.Currency} {account.Balance:N2}");
                        Console.WriteLine($"    Status: {account.Status}");
                        Console.WriteLine();
                    }

                    if (customerAccounts.Any())
                    {
                        var firstAccount = customerAccounts.First();
                        var transactions = await transactionRepo.GetByAccountIdAsync(firstAccount.AccountId);
                        Console.WriteLine($"--- Recent Transactions for Account {firstAccount.AccountNumber} ---");
                        foreach (var transaction in transactions.Take(5))
                        {
                            Console.WriteLine($"  • {transaction.TransactionDate:yyyy-MM-dd HH:mm} | {transaction.TransactionType}");
                            Console.WriteLine($"    Amount: {transaction.Amount:N2} | Balance After: {transaction.BalanceAfter:N2}");
                            Console.WriteLine($"    Status: {transaction.Status}");
                            if (!string.IsNullOrEmpty(transaction.Description))
                                Console.WriteLine($"    Description: {transaction.Description}");
                            Console.WriteLine();
                        }
                    }
                }

                Console.WriteLine("--- Creating a new customer (CRUD: CREATE) ---");
                var newCustomer = new Customer
                {
                    FirstName = "John",
                    LastName = "Doe",
                    Email = $"john.doe.{DateTime.Now.Ticks}@example.com",
                    Phone = "555-0123",
                    Address = "123 Main St, City, State 12345",
                    DateOfBirth = new DateTime(1990, 1, 15),
                    IdNumber = $"ID{DateTime.Now.Ticks}",
                    IsActive = true
                };

                var createdCustomer = await customerRepo.AddAsync(newCustomer);
                Console.WriteLine($"✓ Customer created with ID: {createdCustomer.CustomerId}");
                Console.WriteLine($"  Name: {createdCustomer.FirstName} {createdCustomer.LastName}");
                Console.WriteLine($"  Email: {createdCustomer.Email}\n");

                Console.WriteLine("--- Updating customer (CRUD: UPDATE) ---");
                createdCustomer.Phone = "555-9999";
                var updatedCustomer = await customerRepo.UpdateAsync(createdCustomer);
                Console.WriteLine($"✓ Customer updated - New phone: {updatedCustomer.Phone}\n");

                Console.WriteLine("--- Reading customer (CRUD: READ) ---");
                var readCustomer = await customerRepo.GetByIdAsync(createdCustomer.CustomerId);
                if (readCustomer != null)
                {
                    Console.WriteLine($"✓ Customer retrieved:");
                    Console.WriteLine($"  ID: {readCustomer.CustomerId}");
                    Console.WriteLine($"  Name: {readCustomer.FirstName} {readCustomer.LastName}");
                    Console.WriteLine($"  Email: {readCustomer.Email}");
                    Console.WriteLine($"  Phone: {readCustomer.Phone}\n");
                }

                //Console.WriteLine("--- Deleting customer (CRUD: DELETE) ---");
                //var deleted = await customerRepo.DeleteAsync(createdCustomer.CustomerId);
                //if (deleted)
                //{
                //    Console.WriteLine($"✓ Customer with ID {createdCustomer.CustomerId} has been deleted.\n");
                //}

                Console.WriteLine("--- Fetching active customers ---");
                var activeCustomers = await customerRepo.GetActiveCustomersAsync();
                Console.WriteLine($"Total active customers: {activeCustomers.Count()}\n");

                Console.WriteLine("--- Fetching active accounts ---");
                var activeAccounts = await accountRepo.GetActiveAccountsAsync();
                Console.WriteLine($"Total active accounts: {activeAccounts.Count()}\n");

                Console.WriteLine("=== CRUD Operations Completed Successfully ===");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
            if (ex.InnerException != null)
            {
                Console.WriteLine($"Inner Exception: {ex.InnerException.Message}");
                if (ex.InnerException.InnerException != null)
                {
                    Console.WriteLine($"Inner Inner Exception: {ex.InnerException.InnerException.Message}");
                }
            }
            Console.WriteLine($"Stack Trace: {ex.StackTrace}");
        }

        Console.WriteLine("\nPress any key to exit...");
        Console.ReadKey();
    }
}