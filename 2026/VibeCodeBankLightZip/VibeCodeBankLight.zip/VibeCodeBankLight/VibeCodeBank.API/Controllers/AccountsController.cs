using Microsoft.AspNetCore.Mvc;
using VibeCodeBank.Data.Models;
using VibeCodeBank.Data.Repositories;

namespace VibeCodeBank.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AccountsController : ControllerBase
{
    private readonly IAccountRepository _accountRepository;
    private readonly ILogger<AccountsController> _logger;

    public AccountsController(IAccountRepository accountRepository, ILogger<AccountsController> logger)
    {
        _accountRepository = accountRepository;
        _logger = logger;
    }

    /// <summary>
    /// Get all accounts
    /// </summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<IEnumerable<Account>>> GetAll()
    {
        try
        {
            var accounts = await _accountRepository.GetAllAsync();
            return Ok(accounts);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving all accounts");
            return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving accounts");
        }
    }

    /// <summary>
    /// Get account by ID
    /// </summary>
    [HttpGet("{id}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<Account>> GetById(int id)
    {
        try
        {
            var account = await _accountRepository.GetByIdAsync(id);
            if (account == null)
            {
                return NotFound($"Account with ID {id} not found");
            }
            return Ok(account);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving account with ID {AccountId}", id);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving account");
        }
    }

    /// <summary>
    /// Get accounts by customer ID
    /// </summary>
    [HttpGet("customer/{customerId}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<IEnumerable<Account>>> GetByCustomerId(int customerId)
    {
        try
        {
            var accounts = await _accountRepository.GetByCustomerIdAsync(customerId);
            return Ok(accounts);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving accounts for customer {CustomerId}", customerId);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving customer accounts");
        }
    }

    /// <summary>
    /// Get all active accounts
    /// </summary>
    [HttpGet("active")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<IEnumerable<Account>>> GetActive()
    {
        try
        {
            var accounts = await _accountRepository.GetActiveAccountsAsync();
            return Ok(accounts);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving active accounts");
            return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving active accounts");
        }
    }

    /// <summary>
    /// Create a new account
    /// </summary>
    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<Account>> Create([FromBody] Account account)
    {
        try
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var createdAccount = await _accountRepository.AddAsync(account);
            return CreatedAtAction(nameof(GetById), new { id = createdAccount.AccountId }, createdAccount);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating account");
            return StatusCode(StatusCodes.Status500InternalServerError, "Error creating account");
        }
    }

    /// <summary>
    /// Update an existing account
    /// </summary>
    [HttpPut("{id}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<Account>> Update(int id, [FromBody] Account account)
    {
        try
        {
            if (id != account.AccountId)
            {
                return BadRequest("Account ID mismatch");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var existingAccount = await _accountRepository.GetByIdAsync(id);
            if (existingAccount == null)
            {
                return NotFound($"Account with ID {id} not found");
            }

            var updatedAccount = await _accountRepository.UpdateAsync(account);
            return Ok(updatedAccount);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating account with ID {AccountId}", id);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error updating account");
        }
    }

    /// <summary>
    /// Delete an account
    /// </summary>
    [HttpDelete("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult> Delete(int id)
    {
        try
        {
            var account = await _accountRepository.GetByIdAsync(id);
            if (account == null)
            {
                return NotFound($"Account with ID {id} not found");
            }

            var deleted = await _accountRepository.DeleteAsync(id);
            if (deleted)
            {
                return NoContent();
            }

            return StatusCode(StatusCodes.Status500InternalServerError, "Error deleting account");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting account with ID {AccountId}", id);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error deleting account");
        }
    }
}
