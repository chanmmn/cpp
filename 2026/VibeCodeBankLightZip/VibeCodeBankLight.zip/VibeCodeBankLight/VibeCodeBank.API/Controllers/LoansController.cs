using Microsoft.AspNetCore.Mvc;
using VibeCodeBank.Data.Models;
using VibeCodeBank.Data.Repositories;

namespace VibeCodeBank.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class LoansController : ControllerBase
{
    private readonly ILoanRepository _loanRepository;
    private readonly ILogger<LoansController> _logger;

    public LoansController(ILoanRepository loanRepository, ILogger<LoansController> logger)
    {
        _loanRepository = loanRepository;
        _logger = logger;
    }

    /// <summary>
    /// Get all loans
    /// </summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<IEnumerable<Loan>>> GetAll()
    {
        try
        {
            var loans = await _loanRepository.GetAllAsync();
            return Ok(loans);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving all loans");
            return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving loans");
        }
    }

    /// <summary>
    /// Get loan by ID
    /// </summary>
    [HttpGet("{id}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<Loan>> GetById(int id)
    {
        try
        {
            var loan = await _loanRepository.GetByIdAsync(id);
            if (loan == null)
            {
                return NotFound($"Loan with ID {id} not found");
            }
            return Ok(loan);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving loan with ID {LoanId}", id);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving loan");
        }
    }

    /// <summary>
    /// Get loans by customer ID
    /// </summary>
    [HttpGet("customer/{customerId}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<IEnumerable<Loan>>> GetByCustomerId(int customerId)
    {
        try
        {
            var loans = await _loanRepository.GetByCustomerIdAsync(customerId);
            return Ok(loans);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving loans for customer {CustomerId}", customerId);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving customer loans");
        }
    }

    /// <summary>
    /// Create a new loan
    /// </summary>
    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<Loan>> Create([FromBody] Loan loan)
    {
        try
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var createdLoan = await _loanRepository.AddAsync(loan);
            return CreatedAtAction(nameof(GetById), new { id = createdLoan.LoanId }, createdLoan);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating loan");
            return StatusCode(StatusCodes.Status500InternalServerError, "Error creating loan");
        }
    }

    /// <summary>
    /// Update an existing loan
    /// </summary>
    [HttpPut("{id}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<Loan>> Update(int id, [FromBody] Loan loan)
    {
        try
        {
            if (id != loan.LoanId)
            {
                return BadRequest("Loan ID mismatch");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var existingLoan = await _loanRepository.GetByIdAsync(id);
            if (existingLoan == null)
            {
                return NotFound($"Loan with ID {id} not found");
            }

            var updatedLoan = await _loanRepository.UpdateAsync(loan);
            return Ok(updatedLoan);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating loan with ID {LoanId}", id);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error updating loan");
        }
    }

    /// <summary>
    /// Delete a loan
    /// </summary>
    [HttpDelete("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult> Delete(int id)
    {
        try
        {
            var loan = await _loanRepository.GetByIdAsync(id);
            if (loan == null)
            {
                return NotFound($"Loan with ID {id} not found");
            }

            var deleted = await _loanRepository.DeleteAsync(id);
            if (deleted)
            {
                return NoContent();
            }

            return StatusCode(StatusCodes.Status500InternalServerError, "Error deleting loan");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting loan with ID {LoanId}", id);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error deleting loan");
        }
    }
}
