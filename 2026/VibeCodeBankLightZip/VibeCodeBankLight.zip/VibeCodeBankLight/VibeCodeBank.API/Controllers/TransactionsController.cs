using Microsoft.AspNetCore.Mvc;
using VibeCodeBank.Data.Models;
using VibeCodeBank.Data.Repositories;

namespace VibeCodeBank.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TransactionsController : ControllerBase
{
    private readonly ITransactionRepository _transactionRepository;
    private readonly ILogger<TransactionsController> _logger;

    public TransactionsController(ITransactionRepository transactionRepository, ILogger<TransactionsController> logger)
    {
        _transactionRepository = transactionRepository;
        _logger = logger;
    }

    /// <summary>
    /// Get all transactions
    /// </summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<IEnumerable<Transaction>>> GetAll()
    {
        try
        {
            var transactions = await _transactionRepository.GetAllAsync();
            return Ok(transactions);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving all transactions");
            return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving transactions");
        }
    }

    /// <summary>
    /// Get transaction by ID
    /// </summary>
    [HttpGet("{id}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<Transaction>> GetById(int id)
    {
        try
        {
            var transaction = await _transactionRepository.GetByIdAsync(id);
            if (transaction == null)
            {
                return NotFound($"Transaction with ID {id} not found");
            }
            return Ok(transaction);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving transaction with ID {TransactionId}", id);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving transaction");
        }
    }

    /// <summary>
    /// Get transactions by account ID
    /// </summary>
    [HttpGet("account/{accountId}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<IEnumerable<Transaction>>> GetByAccountId(int accountId)
    {
        try
        {
            var transactions = await _transactionRepository.GetByAccountIdAsync(accountId);
            return Ok(transactions);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving transactions for account {AccountId}", accountId);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving account transactions");
        }
    }

    /// <summary>
    /// Create a new transaction
    /// </summary>
    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<Transaction>> Create([FromBody] Transaction transaction)
    {
        try
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var createdTransaction = await _transactionRepository.AddAsync(transaction);
            return CreatedAtAction(nameof(GetById), new { id = createdTransaction.TransactionId }, createdTransaction);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating transaction");
            return StatusCode(StatusCodes.Status500InternalServerError, "Error creating transaction");
        }
    }

    /// <summary>
    /// Update an existing transaction
    /// </summary>
    [HttpPut("{id}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<Transaction>> Update(int id, [FromBody] Transaction transaction)
    {
        try
        {
            if (id != transaction.TransactionId)
            {
                return BadRequest("Transaction ID mismatch");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var existingTransaction = await _transactionRepository.GetByIdAsync(id);
            if (existingTransaction == null)
            {
                return NotFound($"Transaction with ID {id} not found");
            }

            var updatedTransaction = await _transactionRepository.UpdateAsync(transaction);
            return Ok(updatedTransaction);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating transaction with ID {TransactionId}", id);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error updating transaction");
        }
    }

    /// <summary>
    /// Delete a transaction
    /// </summary>
    [HttpDelete("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult> Delete(int id)
    {
        try
        {
            var transaction = await _transactionRepository.GetByIdAsync(id);
            if (transaction == null)
            {
                return NotFound($"Transaction with ID {id} not found");
            }

            var deleted = await _transactionRepository.DeleteAsync(id);
            if (deleted)
            {
                return NoContent();
            }

            return StatusCode(StatusCodes.Status500InternalServerError, "Error deleting transaction");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting transaction with ID {TransactionId}", id);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error deleting transaction");
        }
    }
}
