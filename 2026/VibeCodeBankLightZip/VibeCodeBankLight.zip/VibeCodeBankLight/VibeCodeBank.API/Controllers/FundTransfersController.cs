using Microsoft.AspNetCore.Mvc;
using VibeCodeBank.Data.Models;
using VibeCodeBank.Data.Repositories;

namespace VibeCodeBank.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class FundTransfersController : ControllerBase
{
    private readonly IFundTransferRepository _fundTransferRepository;
    private readonly ILogger<FundTransfersController> _logger;

    public FundTransfersController(IFundTransferRepository fundTransferRepository, ILogger<FundTransfersController> logger)
    {
        _fundTransferRepository = fundTransferRepository;
        _logger = logger;
    }

    /// <summary>
    /// Get all fund transfers
    /// </summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<IEnumerable<FundTransfer>>> GetAll()
    {
        try
        {
            var transfers = await _fundTransferRepository.GetAllAsync();
            return Ok(transfers);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving all fund transfers");
            return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving fund transfers");
        }
    }

    /// <summary>
    /// Get fund transfer by ID
    /// </summary>
    [HttpGet("{id}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<FundTransfer>> GetById(int id)
    {
        try
        {
            var transfer = await _fundTransferRepository.GetByIdAsync(id);
            if (transfer == null)
            {
                return NotFound($"Fund transfer with ID {id} not found");
            }
            return Ok(transfer);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving fund transfer with ID {TransferId}", id);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving fund transfer");
        }
    }

    /// <summary>
    /// Get fund transfers by account ID
    /// </summary>
    [HttpGet("account/{accountId}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<IEnumerable<FundTransfer>>> GetByAccountId(int accountId)
    {
        try
        {
            var transfers = await _fundTransferRepository.GetByAccountIdAsync(accountId);
            return Ok(transfers);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving fund transfers for account {AccountId}", accountId);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving account fund transfers");
        }
    }

    /// <summary>
    /// Create a new fund transfer
    /// </summary>
    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<FundTransfer>> Create([FromBody] FundTransfer transfer)
    {
        try
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var createdTransfer = await _fundTransferRepository.AddAsync(transfer);
            return CreatedAtAction(nameof(GetById), new { id = createdTransfer.TransferId }, createdTransfer);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating fund transfer");
            return StatusCode(StatusCodes.Status500InternalServerError, "Error creating fund transfer");
        }
    }

    /// <summary>
    /// Update an existing fund transfer
    /// </summary>
    [HttpPut("{id}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<FundTransfer>> Update(int id, [FromBody] FundTransfer transfer)
    {
        try
        {
            if (id != transfer.TransferId)
            {
                return BadRequest("Transfer ID mismatch");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var existingTransfer = await _fundTransferRepository.GetByIdAsync(id);
            if (existingTransfer == null)
            {
                return NotFound($"Fund transfer with ID {id} not found");
            }

            var updatedTransfer = await _fundTransferRepository.UpdateAsync(transfer);
            return Ok(updatedTransfer);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating fund transfer with ID {TransferId}", id);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error updating fund transfer");
        }
    }

    /// <summary>
    /// Delete a fund transfer
    /// </summary>
    [HttpDelete("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult> Delete(int id)
    {
        try
        {
            var transfer = await _fundTransferRepository.GetByIdAsync(id);
            if (transfer == null)
            {
                return NotFound($"Fund transfer with ID {id} not found");
            }

            var deleted = await _fundTransferRepository.DeleteAsync(id);
            if (deleted)
            {
                return NoContent();
            }

            return StatusCode(StatusCodes.Status500InternalServerError, "Error deleting fund transfer");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting fund transfer with ID {TransferId}", id);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error deleting fund transfer");
        }
    }
}
