using Microsoft.AspNetCore.Mvc;
using VibeCodeBank.Data.Services;

namespace VibeCodeBank.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BankingController : ControllerBase
{
    private readonly IBankingService _bankingService;
    private readonly ILogger<BankingController> _logger;

    public BankingController(IBankingService bankingService, ILogger<BankingController> logger)
    {
        _bankingService = bankingService;
        _logger = logger;
    }

    /// <summary>
    /// Get account balance
    /// </summary>
    [HttpGet("accounts/{accountNumber}/balance")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<decimal>> GetBalance(string accountNumber)
    {
        try
        {
            var balance = await _bankingService.GetAccountBalanceAsync(accountNumber);
            return Ok(new { accountNumber, balance });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving balance for account {AccountNumber}", accountNumber);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving account balance");
        }
    }

    /// <summary>
    /// Deposit money into an account
    /// </summary>
    [HttpPost("accounts/{accountNumber}/deposit")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult> Deposit(string accountNumber, [FromBody] DepositRequest request)
    {
        try
        {
            if (request.Amount <= 0)
            {
                return BadRequest("Deposit amount must be greater than zero");
            }

            var transaction = await _bankingService.DepositAsync(accountNumber, request.Amount, request.Description ?? "Deposit");
            if (transaction != null)
            {
                var newBalance = await _bankingService.GetAccountBalanceAsync(accountNumber);
                return Ok(new { message = "Deposit successful", accountNumber, amount = request.Amount, newBalance, transactionId = transaction.TransactionId });
            }

            return BadRequest("Deposit failed");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing deposit for account {AccountNumber}", accountNumber);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error processing deposit");
        }
    }

    /// <summary>
    /// Withdraw money from an account
    /// </summary>
    [HttpPost("accounts/{accountNumber}/withdraw")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult> Withdraw(string accountNumber, [FromBody] WithdrawRequest request)
    {
        try
        {
            if (request.Amount <= 0)
            {
                return BadRequest("Withdrawal amount must be greater than zero");
            }

            var transaction = await _bankingService.WithdrawAsync(accountNumber, request.Amount, request.Description ?? "Withdrawal");
            if (transaction != null)
            {
                var newBalance = await _bankingService.GetAccountBalanceAsync(accountNumber);
                return Ok(new { message = "Withdrawal successful", accountNumber, amount = request.Amount, newBalance, transactionId = transaction.TransactionId });
            }

            return BadRequest("Withdrawal failed - insufficient funds or invalid account");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing withdrawal for account {AccountNumber}", accountNumber);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error processing withdrawal");
        }
    }

    /// <summary>
    /// Transfer money between accounts
    /// </summary>
    [HttpPost("transfer")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult> Transfer([FromBody] TransferRequest request)
    {
        try
        {
            if (request.Amount <= 0)
            {
                return BadRequest("Transfer amount must be greater than zero");
            }

            if (request.FromAccountNumber == request.ToAccountNumber)
            {
                return BadRequest("Cannot transfer to the same account");
            }

            var (fromTransaction, toTransaction) = await _bankingService.TransferAsync(
                request.FromAccountNumber,
                request.ToAccountNumber,
                request.Amount,
                request.Description ?? "Fund transfer");

            if (fromTransaction != null && toTransaction != null)
            {
                var fromBalance = await _bankingService.GetAccountBalanceAsync(request.FromAccountNumber);
                var toBalance = await _bankingService.GetAccountBalanceAsync(request.ToAccountNumber);

                return Ok(new
                {
                    message = "Transfer successful",
                    fromAccountNumber = request.FromAccountNumber,
                    toAccountNumber = request.ToAccountNumber,
                    amount = request.Amount,
                    fromAccountBalance = fromBalance,
                    toAccountBalance = toBalance,
                    fromTransactionId = fromTransaction.TransactionId,
                    toTransactionId = toTransaction.TransactionId
                });
            }

            return BadRequest("Transfer failed - insufficient funds or invalid accounts");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing transfer from account {FromAccountNumber} to {ToAccountNumber}",
                request.FromAccountNumber, request.ToAccountNumber);
            return StatusCode(StatusCodes.Status500InternalServerError, "Error processing transfer");
        }
    }
}

public record DepositRequest(decimal Amount, string? Description);
public record WithdrawRequest(decimal Amount, string? Description);
public record TransferRequest(string FromAccountNumber, string ToAccountNumber, decimal Amount, string? Description);

