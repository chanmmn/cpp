# VibeCodeBank API

A RESTful Web API built with ASP.NET Core 8.0 that provides banking operations for the VibeCodeBank application.

## Features

- **Customer Management**: CRUD operations for customer data
- **Account Management**: Create and manage bank accounts
- **Transaction Management**: Track all banking transactions
- **Loan Management**: Handle loan applications and tracking
- **Fund Transfers**: Transfer money between accounts
- **Banking Operations**: Deposit, withdrawal, and transfer operations with automatic transaction recording

## Technologies

- ASP.NET Core 8.0 Web API
- Entity Framework Core
- PostgreSQL Database
- Swagger/OpenAPI for API documentation
- Repository Pattern
- Dependency Injection

## Getting Started

### Prerequisites

- .NET 8.0 SDK
- PostgreSQL Database
- Visual Studio 2022 or VS Code (optional)

### Running the API

1. **Clone the repository and navigate to the API project:**
   ```bash
   cd VibeCodeBank.API
   ```

2. **Update the connection string** in `appsettings.json` if needed:
   ```json
   "ConnectionStrings": {
     "DefaultConnection": "Host=your-host;Database=mybank;Username=your-username;Password=your-password"
   }
   ```

3. **Run the application:**
   ```bash
   dotnet run
   ```

4. **Access the API:**
   - API Base URL: `https://localhost:7XXX` or `http://localhost:5XXX` (check console output)
   - Swagger UI: `https://localhost:7XXX/swagger`

## API Endpoints

### Customers
- `GET /api/customers` - Get all customers
- `GET /api/customers/{id}` - Get customer by ID
- `GET /api/customers/active` - Get all active customers
- `POST /api/customers` - Create a new customer
- `PUT /api/customers/{id}` - Update a customer
- `DELETE /api/customers/{id}` - Delete a customer

### Accounts
- `GET /api/accounts` - Get all accounts
- `GET /api/accounts/{id}` - Get account by ID
- `GET /api/accounts/customer/{customerId}` - Get accounts by customer ID
- `GET /api/accounts/active` - Get all active accounts
- `POST /api/accounts` - Create a new account
- `PUT /api/accounts/{id}` - Update an account
- `DELETE /api/accounts/{id}` - Delete an account

### Transactions
- `GET /api/transactions` - Get all transactions
- `GET /api/transactions/{id}` - Get transaction by ID
- `GET /api/transactions/account/{accountId}` - Get transactions by account ID
- `GET /api/transactions/account/{accountId}/recent?count=10` - Get recent transactions
- `POST /api/transactions` - Create a new transaction
- `PUT /api/transactions/{id}` - Update a transaction
- `DELETE /api/transactions/{id}` - Delete a transaction

### Loans
- `GET /api/loans` - Get all loans
- `GET /api/loans/{id}` - Get loan by ID
- `GET /api/loans/customer/{customerId}` - Get loans by customer ID
- `POST /api/loans` - Create a new loan
- `PUT /api/loans/{id}` - Update a loan
- `DELETE /api/loans/{id}` - Delete a loan

### Fund Transfers
- `GET /api/fundtransfers` - Get all fund transfers
- `GET /api/fundtransfers/{id}` - Get fund transfer by ID
- `GET /api/fundtransfers/account/{accountId}` - Get fund transfers by account ID
- `POST /api/fundtransfers` - Create a new fund transfer
- `PUT /api/fundtransfers/{id}` - Update a fund transfer
- `DELETE /api/fundtransfers/{id}` - Delete a fund transfer

### Banking Operations
- `GET /api/banking/accounts/{accountNumber}/balance` - Get account balance
- `POST /api/banking/accounts/{accountNumber}/deposit` - Deposit money
  ```json
  {
    "amount": 1000.00,
    "description": "Salary deposit"
  }
  ```
- `POST /api/banking/accounts/{accountNumber}/withdraw` - Withdraw money
  ```json
  {
    "amount": 500.00,
    "description": "ATM withdrawal"
  }
  ```
- `POST /api/banking/transfer` - Transfer money between accounts
  ```json
  {
    "fromAccountNumber": "ACC001",
    "toAccountNumber": "ACC002",
    "amount": 250.00,
    "description": "Transfer to savings"
  }
  ```

## Example Usage

### Create a Customer (Using curl)
```bash
curl -X POST "https://localhost:7XXX/api/customers" \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "John",
    "lastName": "Doe",
    "email": "john.doe@example.com",
    "phone": "555-0123",
    "address": "123 Main St",
    "dateOfBirth": "1990-01-15",
    "idNumber": "ID123456",
    "isActive": true
  }'
```

### Deposit Money
```bash
curl -X POST "https://localhost:7XXX/api/banking/accounts/ACC001/deposit" \
  -H "Content-Type: application/json" \
  -d '{
    "amount": 1000.00,
    "description": "Initial deposit"
  }'
```

### Transfer Money
```bash
curl -X POST "https://localhost:7XXX/api/banking/transfer" \
  -H "Content-Type: application/json" \
  -d '{
    "fromAccountNumber": "ACC001",
    "toAccountNumber": "ACC002",
    "amount": 250.00,
    "description": "Transfer to savings"
  }'
```

## Project Structure

```
VibeCodeBank.API/
├── Controllers/
│   ├── AccountsController.cs
│   ├── BankingController.cs
│   ├── CustomersController.cs
│   ├── FundTransfersController.cs
│   ├── LoansController.cs
│   └── TransactionsController.cs
├── Program.cs
├── appsettings.json
└── VibeCodeBank.API.csproj
```

## Error Handling

The API returns standard HTTP status codes:
- `200 OK` - Successful request
- `201 Created` - Resource created successfully
- `204 No Content` - Successful deletion
- `400 Bad Request` - Invalid request data
- `404 Not Found` - Resource not found
- `500 Internal Server Error` - Server error

## Development

### Building the Project
```bash
dotnet build
```

### Running Tests
```bash
dotnet test
```

### Publishing
```bash
dotnet publish -c Release
```

## License

This project is part of the VibeCodeBank application suite.
