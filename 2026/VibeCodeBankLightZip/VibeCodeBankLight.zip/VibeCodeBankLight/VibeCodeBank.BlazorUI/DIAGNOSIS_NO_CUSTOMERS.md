# Quick Diagnosis: "No customers found" Issue

## The Problem
Your console app shows customers exist in the database, but Blazor UI shows "No customers found."

## Root Cause
The **Blazor UI doesn't connect directly to the database**. It connects to the **API**, which then connects to the database:

```
Blazor UI (port 7055) → API (port 7023) → Database
```

If the API isn't running, Blazor can't get data!

## Quick Fix (Step by Step)

### ✅ Step 1: Verify You Have Customers in Database

Run the console app to confirm:
```powershell
cd C:\test\other\2026\VibeCodeBank\VibeCodeBank
dotnet run
```

You should see: `Total customers: X` (where X > 0)

### ✅ Step 2: Start the API

Open a **NEW** terminal (PowerShell):
```powershell
cd C:\test\other\2026\VibeCodeBank\VibeCodeBank.API
dotnet run
```

**IMPORTANT:** Wait until you see:
```
Now listening on: https://localhost:7023
Now listening on: http://localhost:5044
Application started. Press Ctrl+C to shut down.
```

### ✅ Step 3: Test API Directly

In another terminal or browser:
```powershell
# PowerShell
curl https://localhost:7023/api/customers
```

Or open in browser:
```
https://localhost:7023/swagger
```

You should see customer data!

### ✅ Step 4: Start Blazor UI

Open **ANOTHER** terminal:
```powershell
cd C:\test\other\2026\VibeCodeBank\VibeCodeBank.BlazorUI
dotnet run
```

Wait until you see:
```
Now listening on: https://localhost:7055
```

### ✅ Step 5: Test Blazor UI

1. Open browser: `https://localhost:7055`
2. Click "Customers" in the menu
3. You should now see your customers!

## Still Not Working?

### Use the Built-in Diagnostics Page

1. With both API and Blazor running, navigate to:
   ```
   https://localhost:7055/diagnostics
   ```

2. Click **"Test API Connection"**

3. This will show you exactly what's wrong!

## Common Issues

### Issue 1: API Not Running
**Symptom:** Browser shows "No customers found" with no error

**Check:**
```powershell
# See what's running on port 7023
netstat -ano | findstr :7023
```

**Fix:** Start the API (see Step 2 above)

### Issue 2: Wrong Port
**Symptom:** Connection errors in browser console (F12)

**Check:** Verify API is on port 7023:
- Open `VibeCodeBank.API\Properties\launchSettings.json`
- Look for `"applicationUrl": "https://localhost:7023"`

### Issue 3: SSL Certificate Error
**Symptom:** "SSL connection could not be established"

**Fix:**
```powershell
dotnet dev-certs https --clean
dotnet dev-certs https --trust
```

### Issue 4: API Running but No Data
**Symptom:** API responds but returns empty array

**Check API logs:** Look at the terminal where API is running for database errors

**Fix:** Verify API is using the same database as console app:
- Check `VibeCodeBank.API\appsettings.json`
- Compare with console app's connection string

## Quick Test Commands

### Test 1: Check if customers exist in database
```powershell
cd VibeCodeBank
dotnet run
```
Expected: See customer list

### Test 2: Check if API is running
```powershell
curl https://localhost:7023/api/customers
```
Expected: JSON array with customer data

### Test 3: Check if Blazor can reach API
Navigate to: `https://localhost:7055/diagnostics`
Expected: All tests pass

## Visual Studio Users

If you're using Visual Studio:

1. **Set Multiple Startup Projects:**
   - Right-click Solution → Properties
   - Select "Multiple startup projects"
   - Set both `VibeCodeBank.API` and `VibeCodeBank.BlazorUI` to "Start"

2. **Press F5** - Both will start together!

## Expected Terminal Setup

You should have **TWO** terminals running:

**Terminal 1 - API:**
```
C:\...\VibeCodeBank.API> dotnet run
Now listening on: https://localhost:7023
```

**Terminal 2 - Blazor UI:**
```
C:\...\VibeCodeBank.BlazorUI> dotnet run
Now listening on: https://localhost:7055
```

## Success Checklist

- ✅ Console app shows customers (database works)
- ✅ API running on port 7023
- ✅ Can access https://localhost:7023/swagger
- ✅ Swagger shows customers when you test GET /api/customers
- ✅ Blazor UI running on port 7055
- ✅ Diagnostics page (https://localhost:7055/diagnostics) passes all tests
- ✅ Customers page shows your data!

## Still Having Issues?

Run this PowerShell script to diagnose:

```powershell
Write-Host "=== VibeCodeBank Diagnostics ===" -ForegroundColor Cyan

# Check if API is running
$apiRunning = Test-NetConnection -ComputerName localhost -Port 7023 -InformationLevel Quiet
Write-Host "API (port 7023): " -NoNewline
if ($apiRunning) { Write-Host "✓ RUNNING" -ForegroundColor Green } else { Write-Host "✗ NOT RUNNING" -ForegroundColor Red }

# Check if Blazor is running
$blazorRunning = Test-NetConnection -ComputerName localhost -Port 7055 -InformationLevel Quiet
Write-Host "Blazor (port 7055): " -NoNewline
if ($blazorRunning) { Write-Host "✓ RUNNING" -ForegroundColor Green } else { Write-Host "✗ NOT RUNNING" -ForegroundColor Red }

# Try to get customers from API
if ($apiRunning) {
    try {
        $response = Invoke-WebRequest -Uri "https://localhost:7023/api/customers" -SkipCertificateCheck -ErrorAction Stop
        $customers = $response.Content | ConvertFrom-Json
        Write-Host "Customers in API: " -NoNewline
        Write-Host "$($customers.Count) found" -ForegroundColor Green
    } catch {
        Write-Host "API Error: " -NoNewline
        Write-Host $_.Exception.Message -ForegroundColor Red
    }
}

Write-Host "`n=== Next Steps ===" -ForegroundColor Cyan
if (-not $apiRunning) {
    Write-Host "1. Start API: cd VibeCodeBank.API; dotnet run" -ForegroundColor Yellow
}
if (-not $blazorRunning) {
    Write-Host "2. Start Blazor: cd VibeCodeBank.BlazorUI; dotnet run" -ForegroundColor Yellow
}
if ($apiRunning -and $blazorRunning) {
    Write-Host "Both services running! Open: https://localhost:7055" -ForegroundColor Green
}
```
