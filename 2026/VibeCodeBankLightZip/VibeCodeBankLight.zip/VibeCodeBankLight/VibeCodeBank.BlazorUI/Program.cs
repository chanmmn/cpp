using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using VibeCodeBank.BlazorUI.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();

// Configure HttpClient for API calls
// API is running on HTTP port 5044
builder.Services.AddHttpClient<CustomerService>(client =>
{
    client.BaseAddress = new Uri("http://localhost:5044/");
});

builder.Services.AddHttpClient<AccountService>(client =>
{
    client.BaseAddress = new Uri("http://localhost:5044/");
});

builder.Services.AddHttpClient<TransactionService>(client =>
{
    client.BaseAddress = new Uri("http://localhost:5044/");
});

builder.Services.AddHttpClient<FundTransferService>(client =>
{
    client.BaseAddress = new Uri("http://localhost:5044/");
});

builder.Services.AddHttpClient<LoanService>(client =>
{
    client.BaseAddress = new Uri("http://localhost:5044/");
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();
