Write-Host "=== VibeCodeBank Diagnostics ===" -ForegroundColor Cyan
Write-Host ""

# Check if API is running
Write-Host "Checking API (port 7023)..." -NoNewline
try {
    $apiTest = Test-NetConnection -ComputerName localhost -Port 7023 -InformationLevel Quiet -WarningAction SilentlyContinue
    if ($apiTest) {
        Write-Host " ✓ RUNNING" -ForegroundColor Green
        
        # Try to get customers from API
        Write-Host "Testing API endpoint..." -NoNewline
        try {
            $response = Invoke-RestMethod -Uri "https://localhost:7023/api/customers" -SkipCertificateCheck -ErrorAction Stop
            if ($response -is [Array]) {
                Write-Host " ✓ API responding - $($response.Count) customers found" -ForegroundColor Green
            } else {
                Write-Host " ✓ API responding - 0 customers found" -ForegroundColor Yellow
            }
        } catch {
            Write-Host " ✗ API Error: $($_.Exception.Message)" -ForegroundColor Red
        }
    } else {
        Write-Host " ✗ NOT RUNNING" -ForegroundColor Red
        Write-Host "   → Start API with: cd VibeCodeBank.API; dotnet run" -ForegroundColor Yellow
    }
} catch {
    Write-Host " ✗ NOT RUNNING" -ForegroundColor Red
    Write-Host "   → Start API with: cd VibeCodeBank.API; dotnet run" -ForegroundColor Yellow
}

Write-Host ""

# Check if Blazor is running
Write-Host "Checking Blazor UI (port 7055)..." -NoNewline
try {
    $blazorTest = Test-NetConnection -ComputerName localhost -Port 7055 -InformationLevel Quiet -WarningAction SilentlyContinue
    if ($blazorTest) {
        Write-Host " ✓ RUNNING" -ForegroundColor Green
    } else {
        Write-Host " ✗ NOT RUNNING" -ForegroundColor Red
        Write-Host "   → Start Blazor with: cd VibeCodeBank.BlazorUI; dotnet run" -ForegroundColor Yellow
    }
} catch {
    Write-Host " ✗ NOT RUNNING" -ForegroundColor Red
    Write-Host "   → Start Blazor with: cd VibeCodeBank.BlazorUI; dotnet run" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "=== Summary ===" -ForegroundColor Cyan

$apiRunning = Test-NetConnection -ComputerName localhost -Port 7023 -InformationLevel Quiet -WarningAction SilentlyContinue 2>$null
$blazorRunning = Test-NetConnection -ComputerName localhost -Port 7055 -InformationLevel Quiet -WarningAction SilentlyContinue 2>$null

if ($apiRunning -and $blazorRunning) {
    Write-Host "✓ Both services are running!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Open in browser:" -ForegroundColor Cyan
    Write-Host "  Blazor UI: https://localhost:7055" -ForegroundColor White
    Write-Host "  API Swagger: https://localhost:7023/swagger" -ForegroundColor White
    Write-Host "  Diagnostics: https://localhost:7055/diagnostics" -ForegroundColor White
} elseif ($apiRunning) {
    Write-Host "⚠ API is running but Blazor UI is not" -ForegroundColor Yellow
    Write-Host "  Start Blazor: cd VibeCodeBank.BlazorUI; dotnet run" -ForegroundColor White
} elseif ($blazorRunning) {
    Write-Host "⚠ Blazor UI is running but API is not" -ForegroundColor Yellow
    Write-Host "  This is why you see 'No customers found'" -ForegroundColor Red
    Write-Host "  Start API: cd VibeCodeBank.API; dotnet run" -ForegroundColor White
} else {
    Write-Host "✗ Both services are NOT running" -ForegroundColor Red
    Write-Host ""
    Write-Host "Start them in separate terminals:" -ForegroundColor Yellow
    Write-Host "  Terminal 1: cd VibeCodeBank.API; dotnet run" -ForegroundColor White
    Write-Host "  Terminal 2: cd VibeCodeBank.BlazorUI; dotnet run" -ForegroundColor White
}

Write-Host ""
