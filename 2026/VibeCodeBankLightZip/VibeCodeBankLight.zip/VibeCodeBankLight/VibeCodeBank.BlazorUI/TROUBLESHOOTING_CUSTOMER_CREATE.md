# Troubleshooting "Failed to Create Customer" Error

## Quick Fix Steps

### 1. Verify API is Running

**Check if the API is running on the correct port:**

```powershell
# In Terminal 1 - Start the API
cd VibeCodeBank.API
dotnet run
```

You should see output like:
```
Now listening on: https://localhost:7023
Now listening on: http://localhost:5044
```

### 2. Test API Connection

Once the Blazor app is running, navigate to:
```
https://localhost:7055/diagnostics
```

Click **"Test API Connection"** to diagnose the issue.

### 3. Common Issues and Solutions

#### Issue: API Not Running
**Error:** `HttpRequestException: No connection could be made`

**Solution:**
1. Open a new terminal
2. Navigate to API project: `cd VibeCodeBank.API`
3. Run: `dotnet run`
4. Wait for "Application started" message
5. Refresh Blazor app

#### Issue: Wrong Port
**Error:** `API returned 404` or connection timeout

**Solution:**
Check `VibeCodeBank.BlazorUI/Program.cs` - ensure it matches API port:
```csharp
builder.Services.AddHttpClient<CustomerService>(client =>
{
    client.BaseAddress = new Uri("https://localhost:7023/");  // Must match API port
});
```

#### Issue: SSL Certificate Error
**Error:** `The SSL connection could not be established`

**Solution:**
```powershell
dotnet dev-certs https --trust
```

#### Issue: CORS Error
**Error:** `Access to fetch has been blocked by CORS policy`

**Solution:**
Verify `VibeCodeBank.API/Program.cs` has CORS enabled:
```csharp
app.UseCors("AllowAll");
```

#### Issue: Database Connection
**Error:** `Failed to create customer` with database errors in API console

**Solution:**
1. Check PostgreSQL is running
2. Verify connection string in `appsettings.json`
3. Run migrations if needed

### 4. Step-by-Step Testing

#### Test 1: API Health
```powershell
# Test API directly
curl https://localhost:7023/api/customers
```

Expected: JSON array of customers

#### Test 2: Create Customer via API
```powershell
curl -X POST https://localhost:7023/api/customers `
  -H "Content-Type: application/json" `
  -d '{
    "firstName": "Test",
    "lastName": "User",
    "email": "test@example.com",
    "isActive": true
  }'
```

Expected: JSON of created customer with ID

#### Test 3: Blazor Connection
1. Open Blazor app: `https://localhost:7055`
2. Navigate to: `/diagnostics`
3. Click "Test API Connection"
4. Review detailed test results

### 5. Enhanced Error Messages

The CustomerService now shows detailed errors:
- HTTP status codes
- API error messages  
- Inner exceptions
- Full error context

### 6. Logs to Check

**API Logs** (Terminal running VibeCodeBank.API):
- Look for POST requests to `/api/customers`
- Check for any red error messages
- Note HTTP status codes (200 = success, 400 = bad request, 500 = server error)

**Blazor Logs** (Browser Console - F12):
- Check Network tab for failed requests
- Look at Console tab for JavaScript errors

### 7. Manual Testing in Swagger

Test the API independently:

1. Open: `https://localhost:7023/swagger`
2. Expand `POST /api/customers`
3. Click "Try it out"
4. Enter test data:
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@example.com",
  "phone": "555-0123",
  "address": "123 Main St",
  "isActive": true
}
```
5. Click "Execute"
6. Check response (should be 200 or 201)

### 8. Required Fields

Ensure these fields are filled in the form:
- ✅ First Name (required)
- ✅ Last Name (required)
- ✅ Email (required)
- Optional: Phone, Address, Date of Birth, ID Number

### 9. Network Configuration

If still having issues, check:

**Windows Firewall:**
```powershell
# Allow localhost connections
netsh advfirewall firewall add rule name="ASP.NET Core Web" dir=in action=allow protocol=TCP localport=7023
```

**Hosts File:**
Ensure `127.0.0.1 localhost` exists in:
- Windows: `C:\Windows\System32\drivers\etc\hosts`

### 10. Complete Reset

If all else fails:

```powershell
# Stop all running apps (Ctrl+C in terminals)

# Clean and rebuild
cd C:\test\other\2026\VibeCodeBank
dotnet clean
dotnet build

# Start API
cd VibeCodeBank.API
dotnet run

# In new terminal, start Blazor
cd VibeCodeBank.BlazorUI
dotnet run
```

## Success Indicators

✅ API running: See "Now listening on: https://localhost:7023"
✅ Blazor running: See "Now listening on: https://localhost:7055"
✅ Diagnostics page: All tests pass
✅ Can view customers list
✅ Can create new customer successfully

## Still Having Issues?

Run diagnostics and share the output:
1. Navigate to `https://localhost:7055/diagnostics`
2. Click "Test API Connection"
3. Copy the full diagnostic output
4. Check both terminal windows for error messages
