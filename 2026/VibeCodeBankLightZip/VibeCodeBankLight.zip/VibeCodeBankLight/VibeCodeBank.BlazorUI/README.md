# VibeCodeBank Blazor UI

A modern Blazor Server application for managing banking operations using the VibeCodeBank.API.

## Features

- **Customer Management**: Create, Read, Update, and Delete customer records
- **Account Management**: Manage bank accounts with full CRUD operations
- **Transaction History**: View transaction details for accounts
- **Fund Transfers**: Transfer funds between accounts
- **Loan Management**: Process and manage loan applications

## Prerequisites

- .NET 8.0 SDK or later
- VibeCodeBank.API running on `https://localhost:7023`
- PostgreSQL database configured and running

## Running the Application

1. **Ensure the API is running:**
   ```bash
   cd VibeCodeBank.API
   dotnet run
   ```

2. **Run the Blazor UI:**
   ```bash
   cd VibeCodeBank.BlazorUI
   dotnet run
   ```

3. **Open your browser and navigate to:**
   - HTTPS: `https://localhost:7055`
   - HTTP: `http://localhost:5055`

## Project Structure

```
VibeCodeBank.BlazorUI/
├── Models/              # Data models matching the API
├── Services/            # HTTP services for API communication
├── Pages/               # Razor pages/components
│   ├── Customers.razor
│   ├── CustomerCreate.razor
│   ├── CustomerEdit.razor
│   ├── CustomerDetails.razor
│   ├── Accounts.razor
│   ├── AccountCreate.razor
│   ├── AccountEdit.razor
│   ├── AccountDetails.razor
│   ├── Transactions.razor
│   ├── FundTransfers.razor
│   ├── FundTransferCreate.razor
│   ├── Loans.razor
│   └── LoanCreate.razor
├── Shared/              # Shared components (NavMenu, MainLayout)
└── wwwroot/            # Static files

```

## Configuration

The application is configured to connect to the API at `https://localhost:7023`. 

To change the API URL, update the HttpClient configuration in `Program.cs`:

```csharp
builder.Services.AddHttpClient<CustomerService>(client =>
{
    client.BaseAddress = new Uri("https://your-api-url/");
});
```

## Available Pages

- **Home** (`/`): Dashboard with quick links to all modules
- **Customers** (`/customers`): List and manage customers
- **Accounts** (`/accounts`): List and manage accounts
- **Transactions** (`/transactions`): View transaction history
- **Fund Transfers** (`/fundtransfers`): Manage fund transfers
- **Loans** (`/loans`): Manage loan applications

## Technologies Used

- ASP.NET Core 8.0
- Blazor Server
- Bootstrap 5
- Bootstrap Icons
- HttpClient for API communication

## Development

### Adding New Features

1. Create a model in the `Models` folder
2. Create a service in the `Services` folder
3. Create Razor pages in the `Pages` folder
4. Register the service in `Program.cs`
5. Add navigation links in `Shared/NavMenu.razor`

### Debugging

To debug the application:
1. Set breakpoints in your Razor components or services
2. Press F5 in Visual Studio or run `dotnet watch` in the terminal
3. Use browser developer tools for client-side debugging

## Troubleshooting

### API Connection Issues

If you encounter connection errors:
1. Verify the API is running on `https://localhost:7023`
2. Check the API's Swagger UI at `https://localhost:7023/swagger`
3. Ensure CORS is properly configured in the API
4. Check SSL certificate trust for localhost

### Build Errors

If you encounter build errors:
```bash
dotnet restore
dotnet build
```

## License

This project is part of the VibeCodeBank banking management system.
