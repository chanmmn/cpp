using System.Net.Http.Json;
using VibeCodeBank.BlazorUI.Models;

namespace VibeCodeBank.BlazorUI.Services;

public class LoanService
{
    private readonly HttpClient _httpClient;
    private const string ApiUrl = "api/loans";

    public LoanService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<List<Loan>> GetAllAsync()
    {
        try
        {
            return await _httpClient.GetFromJsonAsync<List<Loan>>(ApiUrl) ?? new List<Loan>();
        }
        catch
        {
            return new List<Loan>();
        }
    }

    public async Task<Loan?> GetByIdAsync(int id)
    {
        try
        {
            return await _httpClient.GetFromJsonAsync<Loan>($"{ApiUrl}/{id}");
        }
        catch
        {
            return null;
        }
    }

    public async Task<List<Loan>> GetByCustomerIdAsync(int customerId)
    {
        try
        {
            return await _httpClient.GetFromJsonAsync<List<Loan>>($"{ApiUrl}/customer/{customerId}") ?? new List<Loan>();
        }
        catch
        {
            return new List<Loan>();
        }
    }

    public async Task<Loan?> CreateAsync(Loan loan)
    {
        try
        {
            var response = await _httpClient.PostAsJsonAsync(ApiUrl, loan);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<Loan>();
        }
        catch
        {
            return null;
        }
    }

    public async Task<bool> UpdateAsync(int id, Loan loan)
    {
        try
        {
            var response = await _httpClient.PutAsJsonAsync($"{ApiUrl}/{id}", loan);
            return response.IsSuccessStatusCode;
        }
        catch
        {
            return false;
        }
    }

    public async Task<bool> DeleteAsync(int id)
    {
        try
        {
            var response = await _httpClient.DeleteAsync($"{ApiUrl}/{id}");
            return response.IsSuccessStatusCode;
        }
        catch
        {
            return false;
        }
    }
}
