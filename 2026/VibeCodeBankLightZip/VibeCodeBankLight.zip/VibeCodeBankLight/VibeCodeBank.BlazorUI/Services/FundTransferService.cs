using System.Net.Http.Json;
using VibeCodeBank.BlazorUI.Models;

namespace VibeCodeBank.BlazorUI.Services;

public class FundTransferService
{
    private readonly HttpClient _httpClient;
    private const string ApiUrl = "api/fundtransfers";

    public FundTransferService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<List<FundTransfer>> GetAllAsync()
    {
        try
        {
            return await _httpClient.GetFromJsonAsync<List<FundTransfer>>(ApiUrl) ?? new List<FundTransfer>();
        }
        catch
        {
            return new List<FundTransfer>();
        }
    }

    public async Task<FundTransfer?> GetByIdAsync(int id)
    {
        try
        {
            return await _httpClient.GetFromJsonAsync<FundTransfer>($"{ApiUrl}/{id}");
        }
        catch
        {
            return null;
        }
    }

    public async Task<List<FundTransfer>> GetByAccountIdAsync(int accountId)
    {
        try
        {
            return await _httpClient.GetFromJsonAsync<List<FundTransfer>>($"{ApiUrl}/account/{accountId}") ?? new List<FundTransfer>();
        }
        catch
        {
            return new List<FundTransfer>();
        }
    }

    public async Task<FundTransfer?> CreateAsync(FundTransfer transfer)
    {
        try
        {
            var response = await _httpClient.PostAsJsonAsync(ApiUrl, transfer);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<FundTransfer>();
        }
        catch
        {
            return null;
        }
    }

    public async Task<bool> UpdateAsync(int id, FundTransfer transfer)
    {
        try
        {
            var response = await _httpClient.PutAsJsonAsync($"{ApiUrl}/{id}", transfer);
            return response.IsSuccessStatusCode;
        }
        catch
        {
            return false;
        }
    }
}
