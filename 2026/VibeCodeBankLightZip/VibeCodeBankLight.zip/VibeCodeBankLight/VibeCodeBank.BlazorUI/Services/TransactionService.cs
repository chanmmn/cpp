using System.Net.Http.Json;
using VibeCodeBank.BlazorUI.Models;

namespace VibeCodeBank.BlazorUI.Services;

public class TransactionService
{
    private readonly HttpClient _httpClient;
    private const string ApiUrl = "api/transactions";

    public TransactionService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<List<Transaction>> GetAllAsync()
    {
        try
        {
            return await _httpClient.GetFromJsonAsync<List<Transaction>>(ApiUrl) ?? new List<Transaction>();
        }
        catch
        {
            return new List<Transaction>();
        }
    }

    public async Task<Transaction?> GetByIdAsync(int id)
    {
        try
        {
            return await _httpClient.GetFromJsonAsync<Transaction>($"{ApiUrl}/{id}");
        }
        catch
        {
            return null;
        }
    }

    public async Task<List<Transaction>> GetByAccountIdAsync(int accountId)
    {
        try
        {
            return await _httpClient.GetFromJsonAsync<List<Transaction>>($"{ApiUrl}/account/{accountId}") ?? new List<Transaction>();
        }
        catch
        {
            return new List<Transaction>();
        }
    }

    public async Task<Transaction?> CreateAsync(Transaction transaction)
    {
        try
        {
            var response = await _httpClient.PostAsJsonAsync(ApiUrl, transaction);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<Transaction>();
        }
        catch
        {
            return null;
        }
    }
}
