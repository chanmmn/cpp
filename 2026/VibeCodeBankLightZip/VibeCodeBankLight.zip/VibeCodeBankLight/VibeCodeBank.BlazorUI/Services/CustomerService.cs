using System.Net.Http.Json;
using VibeCodeBank.BlazorUI.Models;

namespace VibeCodeBank.BlazorUI.Services;

public class CustomerService
{
    private readonly HttpClient _httpClient;
    private const string ApiUrl = "api/customers";

    public CustomerService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<List<Customer>> GetAllAsync()
    {
        try
        {
            return await _httpClient.GetFromJsonAsync<List<Customer>>(ApiUrl) ?? new List<Customer>();
        }
        catch
        {
            return new List<Customer>();
        }
    }

    public async Task<Customer?> GetByIdAsync(int id)
    {
        try
        {
            return await _httpClient.GetFromJsonAsync<Customer>($"{ApiUrl}/{id}");
        }
        catch
        {
            return null;
        }
    }

    public async Task<List<Customer>> GetActiveCustomersAsync()
    {
        try
        {
            return await _httpClient.GetFromJsonAsync<List<Customer>>($"{ApiUrl}/active") ?? new List<Customer>();
        }
        catch
        {
            return new List<Customer>();
        }
    }

    public async Task<Customer?> CreateAsync(Customer customer)
    {
        try
        {
            var response = await _httpClient.PostAsJsonAsync(ApiUrl, customer);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<Customer>();
            }

            var error = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"API returned {response.StatusCode}: {error}");
        }
        catch (Exception ex)
        {
            throw new ApplicationException($"Failed to create customer: {ex.Message}", ex);
        }
    }

    public async Task<bool> UpdateAsync(int id, Customer customer)
    {
        try
        {
            var response = await _httpClient.PutAsJsonAsync($"{ApiUrl}/{id}", customer);
            return response.IsSuccessStatusCode;
        }
        catch
        {
            return false;
        }
    }

    public async Task<bool> DeleteAsync(int id)
    {
        try
        {
            var response = await _httpClient.DeleteAsync($"{ApiUrl}/{id}");
            return response.IsSuccessStatusCode;
        }
        catch
        {
            return false;
        }
    }
}
