using System.Net.Http.Json;
using VibeCodeBank.BlazorUI.Models;

namespace VibeCodeBank.BlazorUI.Services;

public class AccountService
{
    private readonly HttpClient _httpClient;
    private const string ApiUrl = "api/accounts";

    public AccountService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<List<Account>> GetAllAsync()
    {
        try
        {
            return await _httpClient.GetFromJsonAsync<List<Account>>(ApiUrl) ?? new List<Account>();
        }
        catch
        {
            return new List<Account>();
        }
    }

    public async Task<Account?> GetByIdAsync(int id)
    {
        try
        {
            return await _httpClient.GetFromJsonAsync<Account>($"{ApiUrl}/{id}");
        }
        catch
        {
            return null;
        }
    }

    public async Task<List<Account>> GetByCustomerIdAsync(int customerId)
    {
        try
        {
            return await _httpClient.GetFromJsonAsync<List<Account>>($"{ApiUrl}/customer/{customerId}") ?? new List<Account>();
        }
        catch
        {
            return new List<Account>();
        }
    }

    public async Task<List<Account>> GetActiveAccountsAsync()
    {
        try
        {
            return await _httpClient.GetFromJsonAsync<List<Account>>($"{ApiUrl}/active") ?? new List<Account>();
        }
        catch
        {
            return new List<Account>();
        }
    }

    public async Task<Account?> CreateAsync(Account account)
    {
        try
        {
            var response = await _httpClient.PostAsJsonAsync(ApiUrl, account);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<Account>();
        }
        catch
        {
            return null;
        }
    }

    public async Task<bool> UpdateAsync(int id, Account account)
    {
        try
        {
            var response = await _httpClient.PutAsJsonAsync($"{ApiUrl}/{id}", account);
            return response.IsSuccessStatusCode;
        }
        catch
        {
            return false;
        }
    }

    public async Task<bool> DeleteAsync(int id)
    {
        try
        {
            var response = await _httpClient.DeleteAsync($"{ApiUrl}/{id}");
            return response.IsSuccessStatusCode;
        }
        catch
        {
            return false;
        }
    }
}
