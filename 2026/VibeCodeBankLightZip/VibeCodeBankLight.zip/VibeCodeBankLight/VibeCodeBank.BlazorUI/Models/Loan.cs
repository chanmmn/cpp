namespace VibeCodeBank.BlazorUI.Models;

public class Loan
{
    public int LoanId { get; set; }
    public int CustomerId { get; set; }
    public int? AccountId { get; set; }
    public string LoanType { get; set; } = string.Empty;
    public decimal PrincipalAmount { get; set; }
    public decimal InterestRate { get; set; }
    public int TermMonths { get; set; }
    public decimal MonthlyPayment { get; set; }
    public decimal OutstandingBalance { get; set; }
    public string Status { get; set; } = "Pending";
    public DateTime ApplicationDate { get; set; }
    public DateTime? ApprovalDate { get; set; }
    public DateTime? DisbursementDate { get; set; }
    public DateTime? MaturityDate { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public Customer? Customer { get; set; }
    public Account? Account { get; set; }
}
