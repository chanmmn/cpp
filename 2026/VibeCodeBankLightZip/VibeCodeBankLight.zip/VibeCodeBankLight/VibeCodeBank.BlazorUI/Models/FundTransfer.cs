namespace VibeCodeBank.BlazorUI.Models;

public class FundTransfer
{
    public int TransferId { get; set; }
    public int FromAccountId { get; set; }
    public int ToAccountId { get; set; }
    public decimal Amount { get; set; }
    public string? Description { get; set; }
    public DateTime TransferDate { get; set; }
    public string Status { get; set; } = "Pending";
    public string? ReferenceNumber { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public Account? FromAccount { get; set; }
    public Account? ToAccount { get; set; }
}
