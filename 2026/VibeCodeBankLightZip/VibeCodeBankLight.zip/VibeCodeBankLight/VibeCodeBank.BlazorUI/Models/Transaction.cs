namespace VibeCodeBank.BlazorUI.Models;

public class Transaction
{
    public int TransactionId { get; set; }
    public int AccountId { get; set; }
    public string TransactionType { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public decimal BalanceAfter { get; set; }
    public DateTime TransactionDate { get; set; }
    public string? Description { get; set; }
    public string? ReferenceNumber { get; set; }
    public string Status { get; set; } = "Completed";
    public DateTime CreatedAt { get; set; }
    public Account? Account { get; set; }
}
